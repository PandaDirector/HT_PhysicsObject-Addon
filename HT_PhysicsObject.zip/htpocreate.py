import bpy
import re
from .strdef import *

#################################################
##   Main Proc
#################################################
def creation_proc(ps_opt_type, ps_value, bonegroup_number):
        ops_obj = bpy.ops.object

        arm_name = bpy.context.object.name
        tgt_basebone_name = bpy.context.active_bone.name
        base_pfx_name = ADDON_PREFIX + '_' + remove_sfxnum(tgt_basebone_name)
        parent_bone_name = base_pfx_name + '.Parent'
        phyobj_name = base_pfx_name + '.obj' 
        
        ##### OBJECT MODE #####
        ops_obj.mode_set(mode='OBJECT')                                  ## OBJECT mode


        ################
        ## Initialize ##
        ################
        # initialize Setting for this Add-on.
        init_htpo_in_o()

        # enter EDIT (select the armature for the case that several armatures exist).
        arm = select_amarture_in_o(arm_name)
        ##### EDIT MODE #####
        ops_obj.mode_set(mode='EDIT')                                    ## EDIT mode


        ##########################
        ## Create physics bones ##
        ##########################
        # select the target bones.
        bpy.ops.armature.select_all(action='DESELECT')
        root_bone = arm.data.edit_bones.get(tgt_basebone_name)
        select_childbone_in_e(root_bone)
        if root_bone.parent : root_bone.parent.select_tail = True

        # duplicate bones for physics bones.
        bpy.ops.armature.duplicate()
        # rename the physics bones and disable use_deform.
        for bone in bpy.context.selected_bones:
            bone.name = base_pfx_name +'.000'
            bone.use_deform = False
        phy_basebone_name = bpy.context.selected_bones[0].name


        #################################
        ## Create Curve(->Mesh) Object ##
        #################################
        # list the vertcies for creating a curve.
        vtx_list = [arm.matrix_world @ bpy.context.selected_bones[0].head]
        for bone in bpy.context.selected_bones : vtx_list.append(arm.matrix_world @ bone.tail)
        
        ##### OBJECT MODE #####
        ops_obj.mode_set(mode='OBJECT')                                  ## OBJECT mode

        # create the curve with vtx_list.
        ops_obj.select_all(action='DESELECT')
        crvobj = create_polycurve(phyobj_name, vtx_list)
        phyobj_name = crvobj.name  # because same name may be used
        # move the curve object to the collection.
        coll = link2collection(PHYSOBJ_COLL_NAME, crvobj)
        coll.hide_render = True

        # convert from curve to mesh
        crvobj.select_set(True)
        bpy.context.view_layer.objects.active = crvobj
        ops_obj.convert(target='MESH', keep_original=False)
        # create vertex groups and weight the curve with them.
        vg_name_list = create_vertexgroups(base_pfx_name, len(vtx_list), WEIGHT_DEFAULT) 
    
        #############################################################################
        ## Apply the cloth simulation to the curve(mesh) object and set the driver ##
        #############################################################################
        pst_dic = {'PS1' : SRCOBJ1_NAME, 'PS2' : SRCOBJ2_NAME, 'PS3' : SRCOBJ3_NAME}
        ops_obj.modifier_add(type='CLOTH')
        ctx_obj = bpy.context.object
        for mod in ctx_obj.modifiers:   # W/A for other language except english
            if mod.type == 'CLOTH':
                mod.name = 'Cloth'
                break
        ctx_obj.modifiers['Cloth'].settings.vertex_group_mass = vg_name_list[0]
        if ps_opt_type == 'opt1':
            drv = ctx_obj.modifiers['Cloth'].settings.driver_add('pin_stiffness',-1)
            set_driver(drv, 'PinStiffness', pst_dic[ps_value], 'modifiers["Cloth"].settings.pin_stiffness')
        else :
            ctx_obj.modifiers['Cloth'].settings.pin_stiffness = float(ps_value)
        drv2 = bpy.context.object.modifiers['Cloth'].point_cache.driver_add('frame_start',-1)
        set_driver(drv2, 'FrameStart', SRCOBJ1_NAME, 'modifiers["Cloth"].point_cache.frame_start')
        drv3 = bpy.context.object.modifiers['Cloth'].point_cache.driver_add('frame_end',-1)
        set_driver(drv3, 'FrameEnd', SRCOBJ1_NAME, 'modifiers["Cloth"].point_cache.frame_end')


        #####################################################################
        ## Creat the parent bone of the target bones and the physics bones ##
        #####################################################################
        # enter EDIT (select the armature for the case that several armatures exist).
        arm = select_amarture_in_o(arm_name)
   
        ##### EDIT MODE #####
        ops_obj.mode_set(mode='EDIT')                                    ## EDIT mode

        # create parent bone.
        phybone = select_editbone_in_e(arm, phy_basebone_name)
        if phybone.parent : phybone.parent.select_tail = True

        bpy.ops.armature.duplicate()

        parent_bone = bpy.context.active_bone
        parent_bone.name = parent_bone_name
        parent_bone_name = parent_bone.name     # because same bone may exist
        parent_bone.length = phybone.length / 2
        # set the parent bone as the parent of target bone and physics bone.
        tgtbone = arm.data.edit_bones[tgt_basebone_name]
        set_parent(phybone, parent_bone, True)
        #set_parent(tgtbone, parent_bone, False)   #### <-- If you want to set the original bone's parent to the physics bone parent, delete # of top.
      
        ##### OBJECT MODE #####
        ops_obj.mode_set(mode='OBJECT')                                  ## OBJECT mode

        ####################################
        ## Apply bone constraint to bones ##
        ####################################
        # create the list of name of the target bone tree and the physiscs bone tree.
        tgtbone_name_list = create_bonename_list(arm, tgt_basebone_name)
        phybone_name_list = create_bonename_list(arm, phy_basebone_name)
        # apply the DAMPED TRACK constraint to physics bones.
        apply_DAMPED_TRACK(arm, phybone_name_list, phyobj_name, vg_name_list)
        # apply the COPY ROATATION constraint to target bones.
        apply_COPY_ROATION(arm, tgtbone_name_list, phybone_name_list)



        ###################################################
        ## Move the physics bone to specified bone group ##
        ###################################################
        ctx_obj = bpy.context.object
        bone_groups = arm.pose.bone_groups
        active_index = bone_groups.active_index           
        if active_index != int(bonegroup_number):
            for bonename in phybone_name_list:
                bone = ctx_obj.data.bones.get(bonename)
                bone.layers[int(bonegroup_number)] = True
                bone.layers[active_index] = False


        ###############################################
        ## Apply object constraint to physics object ##
        ###############################################
        phyobj = bpy.data.objects[phyobj_name]
        childof = phyobj.constraints.new(type='CHILD_OF')
        childof.target = arm
        childof.subtarget = parent_bone_name



#################################################

# initialize for using this Add-on.
#   used mode: OBJECT mode
def init_htpo_in_o():
    # Create collection.
    create_collection(PHYSOBJ_COLL_NAME)
    # Create collection for the source driver of the driver.
    create_collection(SRCOBJ_COLL_NAME) 

    # Create dummy objects for driver sources.
    create_drvsrcobj(SRCOBJ1_NAME, SRCOBJ_COLL_NAME)
    create_drvsrcobj(SRCOBJ2_NAME, SRCOBJ_COLL_NAME)
    create_drvsrcobj(SRCOBJ3_NAME, SRCOBJ_COLL_NAME)
    
# create the colleciton.
#    if the collection already exits, this method does not do anything.
def create_collection(coll_name):
    res=collection_exists(coll_name)
    if res is False:
        newcoll = bpy.data.collections.new(coll_name)
        bpy.context.scene.collection.children.link(newcoll)

# check the existence of the collection.
def collection_exists(coll_name):
    coll = bpy.data.collections.get(coll_name, None)
    return True if coll is not None else False

# Check the existence of the object under specified collection.
def object_exists_in_collection(obj_name, coll_name):
    coll =  bpy.data.collections.get(coll_name, None)
    obj = bpy.data.objects.get(obj_name, None)
    return False if coll is None or obj is None else coll in obj.users_collection

# remove the numbers(.000, .001, ...) of suffix.
def remove_sfxnum(name):
    return name[:-4] if len(name) > 5 and re.match('\.[0-9]{3}', name[-4:]) else name

# create the source object for driver.
#   used mode: OBJECT mode
def create_drvsrcobj(obj_name,coll_name):
    if object_exists_in_collection(obj_name, coll_name) == True : return  # Do nothing
    # create dummy cube.
    bpy.ops.mesh.primitive_plane_add(size = 0.1, calc_uvs = False, location = (0, 0, -10))
    plane = bpy.context.selected_objects[0]
    plane.name = obj_name
    # set Cloth Simulation.
    bpy.ops.object.modifier_add(type='CLOTH')
    obj = bpy.context.object
    vg = obj.vertex_groups.new(name = obj_name + 'forDriver')
    vg.add([0,1,2,3], 1.0, 'ADD')
    for mod in obj.modifiers:   # W/A for other language except english
        if mod.type == 'CLOTH':
            mod.name = 'Cloth'
            break
    obj.modifiers['Cloth'].settings.vertex_group_mass = vg.name
    obj.modifiers['Cloth'].settings.pin_stiffness = PIN_STIFFNESS_DEFAULT
    # move the object from original collection to specified one.
    orgcoll = plane.users_collection[0]
    orgcoll.objects.unlink(plane)
    coll = link2collection(coll_name, plane)
    # set hide of viewport and render.
    coll.hide_viewport = True
    coll.hide_render = True

# link the object to the Collection.
def link2collection(coll_name, obj):
    coll = bpy.data.collections.get(coll_name)
    coll.objects.link(obj)
    return coll

# select the armature
#   used mode: OBJECT mode
def select_amarture_in_o(arm_name):
    bpy.ops.object.select_all(action='DESELECT')
    arm = bpy.data.objects.get(arm_name, None)
    if arm is None : return arm 
    bpy.context.view_layer.objects.active = arm
    arm.select_set(True)
    return arm

# select the edit bone
#   used mode: EDIT mode
def select_editbone_in_e(arm, bone_name):
    bpy.ops.armature.select_all(action='DESELECT')
    ebone = arm.data.edit_bones.get(bone_name, None)
    if ebone is None : return ebone
    select_bone(ebone)
    return ebone

# select a bone
def select_bone(bone):
    bone.select = True
    bone.select_head = True
    bone.select_tail = True

# select child bones. 
#   used mode: EDIT mode
def select_childbone_in_e(bone):
    cbones = bone.children
    for cbone in cbones : select_childbone_in_e(cbone)
    select_bone(bone)
    return True

# Create the curve with vertices list
#   bevel = resolution is 0, bevel_depth = 0.1
def create_polycurve(crv_name, vlist):
    crvData = bpy.data.curves.new(crv_name, type='CURVE')
    crvData.dimensions = '3D'
    crvData.bevel_resolution = 0
    crvData.bevel_depth = 0.2
    polyline = crvData.splines.new('POLY')
    polyline.points.add(len(vlist)-1)
    for i, vertex in enumerate(vlist):
        x,y,z = vertex
        polyline.points[i].co = (x,y,z,1)
    return bpy.data.objects.new(crv_name, crvData)

# link the object to the Collection
def link2collection(coll_name, obj):
    coll = bpy.data.collections.get(coll_name)
    coll.objects.link(obj)
    return coll

# create the vertex groups
def create_vertexgroups(vg_name, num, sp_weight):
    vg_name_list = []
    for i in range(num):
        j=i*4
        vg = bpy.context.object.vertex_groups.new(name = vg_name + VG_NAME_SFX)
        vg.add([j,j+1,j+2,j+3], 1.0, 'ADD')
        vg_name_list.append(vg.name)
        if i==0 : vg0 = vg
        else : vg0.add([j,j+1,j+2,j+3], sp_weight, 'ADD')
    return vg_name_list

# set dirver to object
def set_driver(drv, var_name, tgt_name, tgt_path):
    drv.driver.type = 'SCRIPTED'
    var = drv.driver.variables.new()
    var.name = var_name
    var.type = 'SINGLE_PROP'
    var.targets[0].id = bpy.data.objects[tgt_name]
    var.targets[0].data_path = tgt_path 
    drv.driver.expression = var.name

# set the Parent bone
# flag = True : copy childb.parent to parentb.parent
def set_parent(child_bone, parent_bone, flag):
    if flag == True and child_bone.parent : parent_bone.parent = child_bone.parent
    child_bone.parent = parent_bone

# get the list of the bone name in the bone tree
def create_bonename_list(arm, bone_name):
    bn_list = [bone_name]
    bone = arm.pose.bones.get(bone_name,None)
    if bone is None : return bn_list
    cbones = bone.children
    for child_bone in cbones:
        bn_list += create_bonename_list(arm, child_bone.name)
    return bn_list

# apply the dump track constraint to the bones
def apply_DAMPED_TRACK(arm, bn_list, phyobj_name, vgn_list):
    for i, bonename in enumerate(bn_list):
        bone = arm.pose.bones.get(bonename)
        dt = bone.constraints.new('DAMPED_TRACK')
        dt.target = bpy.data.objects.get(phyobj_name)
        dt.subtarget = vgn_list[i+1]

# apply the copy rotation constraint to the bones
def apply_COPY_ROATION(arm, bn_list,tgt_list):
    for i, bonename in enumerate(bn_list):
        bone = arm.pose.bones.get(bonename)

        dt = bone.constraints.new('COPY_ROTATION')
        dt.target = arm
        dt.subtarget = tgt_list[i]
        dt.mix_mode = "BEFORE"
        dt.owner_space = "LOCAL"
        dt.target_space = "LOCAL"
