import bpy
from bpy.props import PointerProperty, EnumProperty, FloatProperty, IntProperty, BoolProperty
from bl_ui.properties_physics_common import point_cache_ui
from bl_ui.properties_physics_cloth import cloth_panel_enabled
from .strdef import *
from .htpocreate import creation_proc, collection_exists, object_exists_in_collection, set_driver

#################################################
##   Top Menu
#################################################
class HTPO_MT_Menu(bpy.types.Menu):
    bl_label = ADDON_NICKNAME

    def draw(self, context):
        self.layout.operator_context = 'INVOKE_DEFAULT'
        self.layout.operator(SUBMENU1_IDNAME)
        self.layout.operator(SUBMENU2_IDNAME)
        self.layout.operator(SUBMENU3_IDNAME)

#################################################
##   Create Menu
#################################################
class HTPO_OT_create(bpy.types.Operator):
    bl_label = SUBMENU1_LABEL
    bl_idname = SUBMENU1_IDNAME
    bl_description = "Creat the physics object"
    bl_options = {'REGISTER', 'UNDO', 'INTERNAL'}


    bpy.types.Scene.htpo_crtmenu_ps_option = EnumProperty(name = 'Select PS Setting Option', default = 'opt1', items = [('opt1', 'Use driver', ''), ('opt2', 'Set Value', '')])
    bpy.types.Scene.htpo_crtmenu_ps_type = EnumProperty(
        name = 'Pin Stifffness Type',
        description = 'Please select the pin stiffness type',
        default = 'PS1',
        items = [
            ('PS1','PS1',''),
            ('PS2','PS2',''),
            ('PS3','PS3','')
        ]
    )
    bpy.types.Scene.htpo_crtmenu_pin_stiffness = bpy.props.FloatProperty(name = 'Pin Stiffness', default = PIN_STIFFNESS_DEFAULT, min = 0.00, max = 50.00)
    bpy.types.Scene.htpo_crtmenu_bg_no = EnumProperty(
        name = 'Bone Group',
        description = 'Please select the Bone Group No.',
        default = '31',
        items = [
            ('0','0',''),('1','1',''), ('2','2',''), ('3','3',''), ('4','4',''), 
            ('5','5',''),('6','6',''), ('7','7',''), ('8','8',''), ('9','9',''), 
            ('10','10',''), ('11','11',''), ('12','12',''), ('13','13',''), ('14','14',''), 
            ('15','15',''), ('16','16',''), ('17','17',''), ('18','18',''), ('19','19',''), 
            ('20','20',''), ('21','21',''), ('22','22',''), ('23','23',''), ('24','24',''), 
            ('25','25',''), ('26','26',''), ('27','27',''), ('28','28',''), ('29','29',''), 
            ('30','30',''), ('31','31','')                
        ]
    )

    @classmethod
    def poll(cls, context):
        return (bpy.context.mode == 'EDIT_ARMATURE' and len(bpy.context.selected_editable_bones) == 1)
    
    def draw(self, context):
        scene = context.scene
        layout = self.layout.column()
        
        layout.label(text = 'Settings')
        
        # select the pin stiffness type.
        layout.separator()
        layout.label(text = 'Pin Stiffness Setting', icon='RIGHTARROW_THIN')     
        layout.prop(scene, 'htpo_crtmenu_ps_option', text = '')
        box = layout.box()
        row = box.row()
        if scene.htpo_crtmenu_ps_option == 'opt1':
            row.prop(scene, 'htpo_crtmenu_ps_type', text = 'Pin Stiffness Type', expand = True)
        else:
            row.alignment = 'RIGHT'
            row.prop(scene, 'htpo_crtmenu_pin_stiffness', text = '')

        # set the bone group of created physics bones.
        layout.separator()
        layout.label(text = 'Bone Group', icon='RIGHTARROW_THIN')
        row = layout.row()
        row.alignment = 'RIGHT'
        row.prop(scene, 'htpo_crtmenu_bg_no', text = '')

        layout.separator()

    
    def execute(self, context):
        scene = context.scene
        opt_type = scene.htpo_crtmenu_ps_option
        ps_val = scene.htpo_crtmenu_ps_type if opt_type == 'opt1' else str(scene.htpo_crtmenu_pin_stiffness)
        creation_proc(scene.htpo_crtmenu_ps_option, ps_val, scene.htpo_crtmenu_bg_no)
        return{'FINISHED'}
    
    def invoke(self, context, event):
        wm = context.window_manager
        return wm.invoke_props_dialog(self, width = 150)

#################################################
##   Config Menu
#################################################
class HTPO_OT_configuration(bpy.types.Operator):
    bl_label = SUBMENU2_LABEL
    bl_idname = SUBMENU2_IDNAME
    bl_description = "Change the settings"
    bl_options = {'REGISTER', 'UNDO', 'INTERNAL'}

    def get_phyobj_list(self, context):
        items = []
        coll = bpy.data.collections[PHYSOBJ_COLL_NAME]
        for i, obj in enumerate(coll.all_objects): items.insert(i,(obj.name, obj.name, ''))
        return items

    # if the selected physics object name was updated ...
    def update_phyobj_name(self, context):
        scene = context.scene
        phyobj_name = scene.htpo_cfgmenu_phyobj_name
        phyobj = bpy.data.objects[phyobj_name]
        
        # get the weight value from vertex group
        vg0 = phyobj.vertex_groups[0]
        scene.htpo_cfgmenu_weight = vg0.weight(4)

        # check the existence of the driver and get current driver/value.
        pst_dic = {SRCOBJ1_NAME : 'PS1', SRCOBJ2_NAME : 'PS2', SRCOBJ3_NAME : 'PS3'}
        drvs = phyobj.animation_data.drivers
        drv_exists = False
        if drvs is not None:
         for drv in drvs:
            tgt_path = drv.data_path
            tgtobj_name = drv.driver.variables[0].targets[0].id.name
            if tgt_path == 'modifiers["Cloth"].settings.pin_stiffness':
                scene.htpo_cfgmenu_ps_option = 'opt1'
                scene.htpo_cfgmenu_ps_type = pst_dic[tgtobj_name]
                drv_exists = True
                break
        if not drv_exists: 
            scene.htpo_cfgmenu_ps_option = 'opt2'
            ps = get_path_clothsettings(phyobj_name)
            scene.htpo_cfgmenu_pin_stiffness = ps.pin_stiffness

    # if the ps option was updated ...
    def update_phyobj_ps_option(self, context):
        scene = context.scene
        phyobj_name = scene.htpo_cfgmenu_phyobj_name
        phyobj = bpy.data.objects[phyobj_name]
        if scene.htpo_cfgmenu_ps_option == 'opt2':
            ps = get_path_clothsettings(phyobj_name)
            scene.htpo_cfgmenu_pin_stiffness = ps.pin_stiffness
    
    bpy.types.Scene.htpo_cfgmenu_ps1_value = bpy.props.FloatProperty(name = 'PS1 Value', default = 1.00, min = 0.00, max = 50.00)
    bpy.types.Scene.htpo_cfgmenu_ps2_value = bpy.props.FloatProperty(name = 'PS2 Value', default = 1.00, min = 0.00, max = 50.00)
    bpy.types.Scene.htpo_cfgmenu_ps3_value = bpy.props.FloatProperty(name = 'PS3 Value', default = 1.00, min = 0.00, max = 50.00)
    bpy.types.Scene.htpo_cfgmenu_phyobj_name = bpy.props.EnumProperty(name = 'Physics Object Name', items = get_phyobj_list, update = update_phyobj_name)
    bpy.types.Scene.htpo_cfgmenu_weight = bpy.props.FloatProperty(name = 'Weight', default = WEIGHT_DEFAULT, min = 0.00, max = 1.00)
    bpy.types.Scene.htpo_cfgmenu_ps_option = EnumProperty(name = 'Select PS Setting Option', default = 'opt1', items = [('opt1', 'Use driver', ''), ('opt2', 'Set Value', '')], update = update_phyobj_ps_option)
    bpy.types.Scene.htpo_cfgmenu_ps_type = EnumProperty(
        name = 'Pin Stiffness Type',
        description = 'Please select pin stiffness type',
        default = 'PS1',
        items = [
            ('PS1','PS1',''),
            ('PS2','PS2',''),
            ('PS3','PS3','')
        ]
    )
    bpy.types.Scene.htpo_cfgmenu_pin_stiffness = bpy.props.FloatProperty(name = 'Pin Stiffness', default = PIN_STIFFNESS_DEFAULT, min = 0.00, max = 50.00)

    @classmethod
    def poll(cls, context):
        mode = bpy.context.object.mode
        # can use only in OBJECT, POSE, or WEIGHT_PAINT
        if mode != 'OBJECT' and mode != 'POSE' and mode != 'WEIGHT_PAINT': return False
        # if any driver does not exist, gray-out the menu
        return (object_exists_in_collection(SRCOBJ1_NAME, SRCOBJ_COLL_NAME) and
        object_exists_in_collection(SRCOBJ2_NAME, SRCOBJ_COLL_NAME) and
        object_exists_in_collection(SRCOBJ3_NAME, SRCOBJ_COLL_NAME))
    
    def draw(self, context):
        scene = context.scene
        layout = self.layout.column()
        cset1 = get_path_clothsettings(SRCOBJ1_NAME)
        cset2 = get_path_clothsettings(SRCOBJ2_NAME)
        cset3 = get_path_clothsettings(SRCOBJ3_NAME)
        cpc = get_path_clothpointcache(SRCOBJ1_NAME)

        # set the pin stiffness of drivers
        layout.separator()
        layout.label(text = 'Pin Stiffness Driver', icon='RIGHTARROW_THIN')
        box = layout.box()
        row = box.row()
        row.label(text = 'PS1')
        if cset1 is None : row.label(text = NOT_AVAIL)
        else : row.prop(scene, 'htpo_cfgmenu_ps1_value', text='')
        row = box.row()
        row.label(text = 'PS2')
        if cset2 is None : row.label(text = NOT_AVAIL)
        else : row.prop(scene, 'htpo_cfgmenu_ps2_value', text='')
        row = box.row()
        row.label(text = 'PS3')
        if cset3 is None : row.label(text = NOT_AVAIL)
        else : row.prop(scene, 'htpo_cfgmenu_ps3_value', text='')

        # select the Physics Object Name
        layout.separator()
        layout.separator()
        row = layout.row()
        mode = bpy.context.object.mode
        row.label(text = 'Physics Object', icon='RIGHTARROW_THIN')
        if (collection_exists(PHYSOBJ_COLL_NAME) == False or 
            htpo_object_exists_in_collection(PHYSOBJ_COLL_NAME) == False):
            row.label(text = NOT_AVAIL)
            box = layout.box()
            row = box.row()
            row.label(text = NOT_AVAIL)
        else: 
            row.prop(scene, 'htpo_cfgmenu_phyobj_name', text = '')
            box = layout.box()
            row = box.row()
            row.label(text = 'Weight')
            row.prop(scene, 'htpo_cfgmenu_weight', text = '')
            row = box.row()
            row.label(text = 'Pin Stiffness Setting')            
            row.prop(scene, 'htpo_cfgmenu_ps_option', text = '')
            row = box.row()
            if scene.htpo_cfgmenu_ps_option == 'opt1':
                row.prop(scene, 'htpo_cfgmenu_ps_type', text = 'Pin Stiffness Type', expand = True)
            else:
                row.alignment = 'RIGHT'
                row.prop(scene, 'htpo_cfgmenu_pin_stiffness', text = '')
        
        layout.separator()

    def execute(self, context):
        scene = context.scene
        phyobj_name = scene.htpo_cfgmenu_phyobj_name
        phyobj = bpy.data.objects[phyobj_name]

        # set the pin stiffness of srcobj for driver
        cset1 = get_path_clothsettings(SRCOBJ1_NAME)
        cset2 = get_path_clothsettings(SRCOBJ2_NAME)
        cset3 = get_path_clothsettings(SRCOBJ3_NAME)
        if cset1 is not None : cset1.pin_stiffness = scene.htpo_cfgmenu_ps1_value
        if cset2 is not None : cset2.pin_stiffness = scene.htpo_cfgmenu_ps2_value
        if cset3 is not None : cset3.pin_stiffness = scene.htpo_cfgmenu_ps3_value        

        # set the weight
        count = len(phyobj.data.vertices)
        vg0 = phyobj.vertex_groups[0]
        if count > 4:
            vtx_list = []
            for i in range(count) : 
                if i > 3 : vtx_list.append(i)
            vg0.add(vtx_list, context.scene.htpo_cfgmenu_weight, 'REPLACE')

        # set the pin stiffness
        if collection_exists(PHYSOBJ_COLL_NAME) != False and htpo_object_exists_in_collection(PHYSOBJ_COLL_NAME) != False:
            pst_dic = {'PS1' : SRCOBJ1_NAME, 'PS2' : SRCOBJ2_NAME, 'PS3' : SRCOBJ3_NAME}
            drvs = phyobj.animation_data.drivers
            drv_exists = False
            # is the driver already set?
            if drvs is not None:
                for drv in drvs:
                    tgt_path = drv.data_path
                    tgtobj_name = drv.driver.variables[0].targets[0].id.name
                    if tgt_path == 'modifiers["Cloth"].settings.pin_stiffness':
                        phyobj.modifiers['Cloth'].settings.driver_remove("pin_stiffness", -1)
                        if scene.htpo_cfgmenu_ps_option == 'opt1' :
                            newdrv = phyobj.modifiers['Cloth'].settings.driver_add('pin_stiffness',-1)
                            ps_type = pst_dic[scene.htpo_cfgmenu_ps_type]
                            set_driver(newdrv, 'PinStiffness', ps_type, 'modifiers["Cloth"].settings.pin_stiffness')   
                        else :
                            path = get_path_clothsettings(phyobj_name)
                            path.pin_stiffness = scene.htpo_cfgmenu_pin_stiffness
                        drv_exists = True
                        break

            if not drv_exists:
                if scene.htpo_cfgmenu_ps_option == 'opt1':
                    newdrv = phyobj.modifiers['Cloth'].settings.driver_add('pin_stiffness',-1)
                    ps_type = pst_dic[scene.htpo_cfgmenu_ps_type]
                    set_driver(newdrv, 'PinStiffness', ps_type, 'modifiers["Cloth"].settings.pin_stiffness')                    
                else:
                    path = get_path_clothsettings(phyobj_name)
                    path.pin_stiffness = scene.htpo_cfgmenu_pin_stiffness

        return{'FINISHED'}
    
    def invoke(self, context, event):
        wm = context.window_manager
        scene = context.scene

        # initalize this operator
        self.update_phyobj_name(context)
        
        cset1 = get_path_clothsettings(SRCOBJ1_NAME)
        cset2 = get_path_clothsettings(SRCOBJ2_NAME)
        cset3 = get_path_clothsettings(SRCOBJ3_NAME)
        if cset1 is not None : scene.htpo_cfgmenu_ps1_value = cset1.pin_stiffness
        if cset2 is not None : scene.htpo_cfgmenu_ps2_value = cset2.pin_stiffness
        if cset3 is not None : scene.htpo_cfgmenu_ps3_value = cset3.pin_stiffness

        return wm.invoke_props_dialog(self)

#################################################
##   Bake Menu
#################################################
class HTPO_OT_bake(bpy.types.Operator):
    bl_label = SUBMENU3_LABEL
    bl_idname = SUBMENU3_IDNAME
    bl_description = "Baking the cloth simulation"
    bl_options = {'REGISTER', 'UNDO', 'INTERNAL'}

    @classmethod
    def poll(cls, context):
        mode = bpy.context.object.mode
        # can use only in OBJECT, POSE, or WEIGHT_PAINT
        if mode != 'OBJECT' and mode != 'POSE' and mode != 'WEIGHT_PAINT': return False
        # if any driver does not exist, gray-out the menu
        return object_exists_in_collection(SRCOBJ1_NAME, SRCOBJ_COLL_NAME)

    def draw(self, context):
        md = get_cloth_modifier(SRCOBJ1_NAME)
        point_cache_ui(self, md.point_cache, cloth_panel_enabled(md), 'CLOTH')
    
    def execute(self, context):
        return{'FINISHED'}

    def invoke(self, context, event):
        wm = context.window_manager
        #    return wm.invoke_props_dialog(self)
        return wm.invoke_popup(self)
        
def get_cloth_modifier(objname):
    obj = bpy.data.objects.get(objname, None)
    if obj is not None:
        cloth = obj.modifiers.get('Cloth', None)
        if cloth is not None : return cloth
    return None

def get_path_clothsettings(objname):
    obj = bpy.data.objects.get(objname, None)
    cset = None
    if obj is not None:
        cloth = obj.modifiers.get('Cloth', None)
        if cloth is not None : cset = cloth.settings
    return cset

def get_path_clothpointcache(objname):
    obj = bpy.data.objects.get(objname, None)
    cpc = None
    if obj is not None:
        cloth = obj.modifiers.get('Cloth', None)
        if cloth is not None : cpc = cloth.point_cache
    return cpc

def htpo_object_exists_in_collection(col_name):
    coll = bpy.data.collections[col_name]
    for i, obj in enumerate(coll.all_objects): 
        if obj.name[:5] == ADDON_NICKNAME + '_' : return True
    return False
 