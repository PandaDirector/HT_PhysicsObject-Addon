# definition of the string
ADDON_NICKNAME = 'HTPO'

ADDON_PREFIX = ADDON_NICKNAME
PHYSOBJ_COLL_NAME = 'HTPO_Physics_Object'
SRCOBJ_COLL_NAME = 'HTPO_OBJ_For_Driver'
SRCOBJ1_NAME = 'HTPO_SrcObj.000'
SRCOBJ2_NAME = 'HTPO_SrcObj.001'
SRCOBJ3_NAME = 'HTPO_SrcObj.002'
SUBMENU1_LABEL = 'Create'
SUBMENU1_IDNAME = 'wm.htposubmenu1'
SUBMENU2_LABEL = 'Config'
SUBMENU2_IDNAME = 'object.hbosubmenu2'
SUBMENU3_LABEL = 'Bake'
SUBMENU3_IDNAME = 'object.hbosubmenu3'

VG_NAME_SFX = '.VG.000'
PIN_STIFFNESS_DEFAULT = 0.5
WEIGHT_DEFAULT = 0.2

# mseegage
NOT_AVAIL = 'Not Abailable'
