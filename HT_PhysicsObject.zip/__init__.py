if 'bpy' in locals():
    import imp
    imp.reload(strdef)
    imp.reload(htpomenu)
    imp.reload(htpocreate)
else:
    from . import strdef
    from . import htpomenu
    from . import htpocreate

import bpy

bl_info = {
    'name' : 'HT Physics Object',
    'author' : 'PandaDirector',
    'description' : '',
    'blender' : (3, 3, 1),
    'version' : (1, 0, 0),
    'location' : "3DView",
    'warning' : '',
    'Support' : 'COMMUNITY',
    'doc_url' : 'https://pandadirector.hatenablog.com/entry/HTPO_addon/eng',
    'category' : 'Object'
}

classes = [
    htpomenu.HTPO_MT_Menu,
    htpomenu.HTPO_OT_create,
    htpomenu.HTPO_OT_configuration,
    htpomenu.HTPO_OT_bake,
]

def addmenu_callback(self, context):
    self.layout.menu('HTPO_MT_Menu')

def register():
    for cls in classes:
        bpy.utils.register_class(cls)
    bpy.types.VIEW3D_MT_editor_menus.append(addmenu_callback)

def unregister():
    bpy.types.VIEW3D_MT_editor_menus.remove(addmenu_callback)
    for cls in classes:
        bpy.utils.unregister_class(cls)

if __name__ == "__main__":
    register()